[TOC]

| a | b |
| --- | --- |
| 1 | 2 |

#### Crypto
[crypto](/crypto/test)

#### DSP
[dsp/dealDup](dsp/dealDup)
[dsp/blueStarInfo](lxthyme/game/dsp/blueStarInfo)
[dsp/diff](lxthyme/game/dsp/diff)
[dsp/get](lxthyme/game/dsp/get)
[dsp/get2](lxthyme/game/dsp/get2)
[dsp/get3](lxthyme/game/dsp/get3)

##### 外链
[自动生成无带蓝图: svlik.com/t/dsq](https://www.svlik.com/t/dsq)
[dsp-calc.pro](https://dsp-calc.pro/)
[dsp_blueprint_editor](https://huww98.github.io/dsp_blueprint_editor)
[dsp-calculator](https://eurydia.github.io/dsp-calculator/)
[factoriolab.github.io/list](https://factoriolab.github.io/list?z=eJxTS.JQSzPU8op3BuJkLff4TC0vtWItLbM6J6M6J986p5A6p.A6p6w6p6I654A655A6.7qIusi6qLrkutK6Ci1nLXctFOClVmYOAG0MGbk_&v=7)
[戴森球蓝图(DysonSphereBluePrints)](https://github.com/DSPBluePrints/DysonSphereBluePrints)
[DSP 蓝图(FactoryBluePrints)](https://github.com/DSPBluePrints/FactoryBluePrints)
[https://github.com/bWFuanVzYWth/dspbptk](https://github.com/bWFuanVzYWth/dspbptk)
[仙术: edit-dspblue-print](https://github.com/cying314/edit-dspblue-print)

#### GTA 5
[gtaWeb.eu](https://gtaweb.eu)
[GTA5线上小助手](https://github.com/CrazyZhang666/GTA5OnlineTools/releases)
[https://gtacars.net](https://gtacars.net)
[https://gtalens.com/?page=1&platforms=pc](https://gtalens.com/?page=1&platforms=pc)

#### Slay The Spire
[slaythespire](/slaythespire)
[save-the-spire.vercel.app](https://save-the-spire.vercel.app)

#### pvz2
[pvz2/fmt](pvz2/fmt)

#### NMS
[NMSSaveEditor](https://github.com/goatfungus/NMSSaveEditor)
[nms.center](https://nms.center/)
{/* `'` can be escaped with `&apos;`, `&lsquo;`, `&#39;`, `&rsquo;` */}
[Collection of CSV files with values of every procedural item in No Man&apos;s Sky.](https://github.com/zencq/Pi)

#### Dead Cells
[Dead Cells Roadmap](https://deadcells.wiki.gg/wiki/Biomes_map)

#### PalWorld
[踩蘑菇论坛社区: 里面有地图, 图鉴, 配种, 词条, 技能, mod](https://palworld.caimogu.cc/breed.html)
[Excel表格: https://docs.qq.com/sheet/DT05PeVVoekZiamlh?tab=000001](https://docs.qq.com/sheet/DT05PeVVoekZiamlh?tab=000001)
[地图攻略: https://map.caimogu.cc/palworld/paru_islands.html](https://map.caimogu.cc/palworld/paru_islands.html)
[幻兽帕鲁MOD圈: https://www.caimogu.cc/circle/426.html](https://www.caimogu.cc/circle/426.html)
[技能查询: https://palworld.caimogu.cc/skill.html](https://palworld.caimogu.cc/skill.html)
[Excel表格: https://docs.qq.com/sheet/DT05PeVVoekZiamlh?tab=000001](https://docs.qq.com/sheet/DT05PeVVoekZiamlh?tab=000001)
